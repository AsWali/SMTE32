//
//  City.swift
//  HellGlow swift cmd
//
//  Created by fhict on 06/03/15.
//  Copyright (c) 2015 fhict. All rights reserved.
//

import Foundation

class City {
    
    var name:String = "";
    var population:Int = 0;
    var glowActs:[GlowAct] = [];
    
    init(name:String, population:Int)
    {
        self.name = name;
        self.population = population;
        
    }
    
    func showInfo(){
        
        var print = "In the city of \(name) there are currently living \(population) people and there are \(glowActs.count) glow acts" + "\n";
        
        
        for i in glowActs
        {
            print += "\(i.showInfo()) \n";
        }
        
        println(print)
    }
}
