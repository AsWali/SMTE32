//
//  main.swift
//  HellGlow swift cmd
//
//  Created by fhict on 06/03/15.
//  Copyright (c) 2015 fhict. All rights reserved.
//

import Foundation

        var blueLightAct : GlowAct = GlowAct(name: "The Bluelight act" , rating: 8, startTime: "22:20")
        var redLightAct : GlowAct = GlowAct(name: "The redlight act" , rating: 7, startTime: "20:20")
        var eindhoven : City = City(name: "Eindhoven", population: 220000)
        eindhoven.glowActs.append(blueLightAct);
        eindhoven.glowActs.append(redLightAct);
        eindhoven.showInfo();


