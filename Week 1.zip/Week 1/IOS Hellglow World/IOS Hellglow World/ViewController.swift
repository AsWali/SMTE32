//
//  ViewController.swift
//  IOS Hellglow World
//
//  Created by fhict on 06/03/15.
//  Copyright (c) 2015 fhict. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func ShowInfo(sender: AnyObject) {
        let alert = UIAlertController(title: "Welcome to my First App", message: "Hellglow World", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }

}

