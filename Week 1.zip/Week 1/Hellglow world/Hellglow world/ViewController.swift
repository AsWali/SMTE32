//
//  ViewController.swift
//  Hellglow world
//
//  Created by fhict on 05/03/15.
//  Copyright (c) 2015 fhict. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
     
    }
    



    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    

    
    
    @IBAction func ShowInfoGlowact(sender: AnyObject) {
        var blueLightAct : GlowAct = GlowAct(name: "The Bluelight act" , rating: 8, startTime: "22:20")
        var redLightAct : GlowAct = GlowAct(name: "The redlight act" , rating: 7, startTime: "20:20")
        var eindhoven : City = City(name: "Eindhoven", population: 220000)
        eindhoven.glowActs.append(blueLightAct);
        eindhoven.glowActs.append(redLightAct);
        Infolabel.stringValue = eindhoven.showInfo();
    }

    @IBOutlet weak var Infolabel: NSTextField!
    
    
    



}

