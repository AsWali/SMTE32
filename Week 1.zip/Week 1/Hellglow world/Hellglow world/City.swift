//
//  City.swift
//  Hellglow world
//
//  Created by fhict on 05/03/15.
//  Copyright (c) 2015 fhict. All rights reserved.
//

import Foundation

class City {
    
var name:String = "";
var population:Int = 0;
var glowActs:[GlowAct] = [];

    init(name:String, population:Int)
    {
        self.name = name;
        self.population = population;

    }
    
    func showInfo() -> String{
    
        var alleinfo:String = "" ;
        alleinfo += "In the city of \(name) there are currently living \(population) people and there are \(glowActs.count) glow acts" + "\n";
        
        
        for i in glowActs
        {
            alleinfo += "\(i.showInfo()) \n";
        }
        

        return alleinfo;
    
    }
}

